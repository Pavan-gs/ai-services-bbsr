from fastapi import Depends, FastAPI, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from database import Base, engine, get_db
from models import Consultant, PracticeArea
from schemas import (
    ConsultantCreate,
    ConsultantOut,
    PracticeAreaCreate,
    PracticeAreaOut,
    ConsultantUpdate,
    PracticeAreaWithConsultants,
)
'''
Base.metadata.create_all(bind=engine)
app = FastAPI(title="Practice Area and Consultant API")


@app.post("/practice-areas", response_model=PracticeAreaOut, status_code=201)
def create_practice_area(
    practice_area: PracticeAreaCreate,
    db: Session = Depends(get_db),
):
    item = PracticeArea(**practice_area.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@app.post(
    "/practice-areas/{practice_area_id}/consultants",
    response_model=ConsultantOut,
    status_code=201,
)
def add_consultant(
    practice_area_id: int,
    consultant: ConsultantCreate,
    db: Session = Depends(get_db),
):
    parent = db.get(PracticeArea, practice_area_id)
    if parent is None:
        raise HTTPException(status_code=404, detail="Practice area not found")

    item = Consultant(
        **consultant.model_dump(),
        practice_area_id=practice_area_id,
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@app.get(
    "/practice-areas/{practice_area_id}",
    response_model=PracticeAreaWithConsultants,
)
def get_practice_area(
    practice_area_id: int,
    designation: str | None = Query(default=None),
    sort: str | None = Query(default=None),
    db: Session = Depends(get_db),
):
    parent = db.get(PracticeArea, practice_area_id)
    if parent is None:
        raise HTTPException(status_code=404, detail="Practice area not found")

    consultants = list(parent.consultants)

    if designation is not None and designation.strip():
        consultants = [c for c in consultants if c.designation == designation]

    if sort is not None:
        if sort not in ("name", "consultation_fee"):
            raise HTTPException(status_code=404, detail="Invalid sort field")
        consultants.sort(key=lambda c: getattr(c, sort), reverse=True)

    return {
        "id": parent.id,
        "name": parent.name,
        "floor_number": parent.floor_number,
        "consultants": consultants,
    }

# GET /practice-areas/1
# GET /practice-areas/1?designation=Senior%20Consultant
# GET /practice-areas/1?sort=name
# GET /practice-areas/1?designation=Senior%20Consultant&sort=name
# 

@app.put(
    "/practice-areas/{practice_area_id}/consultants/{consultant_id}",
    response_model=ConsultantOut
)
def update_consultant(
    practice_area_id: int,
    consultant_id: int,
    data: ConsultantUpdate,
    db: Session = Depends(get_db),
):
    consultant = db.query(Consultant).filter(
        Consultant.id == consultant_id,
        Consultant.practice_area_id == practice_area_id
    ).first()

    if consultant is None:
        raise HTTPException(
            status_code=404,
            detail="Consultant not found in this practice area"
        )

    update_data = data.model_dump(exclude_unset=True)

    for field, value in update_data.items():
        setattr(consultant, field, value)

    db.commit()
    db.refresh(consultant)

    return consultant


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
'''

app = FastAPI(title="Practice Area and Consultant API")

# ------------------------------------------------------------
# Helper 1: Find the parent practice area
# ------------------------------------------------------------

def require_practice_area(db: Session, practice_area_id: int):
    parent = db.get(PracticeArea, practice_area_id)

    if parent is None:
        raise HTTPException(
            status_code=404,
            detail="Practice area not found"
        )

    return parent


# ------------------------------------------------------------
# Helper 2: Find a consultant belonging to this parent
# ------------------------------------------------------------

def require_consultant(
    db: Session,
    practice_area_id: int,
    consultant_id: int
):
    consultant = (
        db.query(Consultant)
        .filter(
            Consultant.id == consultant_id,
            Consultant.practice_area_id == practice_area_id
        )
        .first()
    )

    if consultant is None:
        raise HTTPException(
            status_code=404,
            detail="Consultant not found in this practice area"
        )

    return consultant


# ------------------------------------------------------------
# Helper 3: Commit a write safely
# ------------------------------------------------------------

def commit_write(db: Session, record=None):
    try:
        db.commit()

        if record is not None:
            db.refresh(record)

    except SQLAlchemyError as exc:
        db.rollback()

        raise HTTPException(
            status_code=500,
            detail="Database operation failed"
        ) from exc


# ------------------------------------------------------------
# Endpoint 1: Create a practice area
# ------------------------------------------------------------

@app.post(
    "/practice-areas",
    response_model=PracticeAreaOut,
    status_code=201
)
def create_practice_area(
    practice_area: PracticeAreaCreate,
    db: Session = Depends(get_db)
):
    item = PracticeArea(**practice_area.model_dump())

    db.add(item)
    commit_write(db, item)

    return item


# ------------------------------------------------------------
# Endpoint 2: Add a consultant to a practice area
# ------------------------------------------------------------

@app.post(
    "/practice-areas/{practice_area_id}/consultants",
    response_model=ConsultantOut,
    status_code=201
)
def add_consultant(
    practice_area_id: int,
    consultant: ConsultantCreate,
    db: Session = Depends(get_db)
):
    require_practice_area(db, practice_area_id)

    item = Consultant(
        **consultant.model_dump(),
        practice_area_id=practice_area_id
    )

    db.add(item)
    commit_write(db, item)

    return item


# ------------------------------------------------------------
# Endpoint 3: Get a practice area with its consultants
# ------------------------------------------------------------

@app.get(
    "/practice-areas/{practice_area_id}",
    response_model=PracticeAreaWithConsultants
)
def get_practice_area(
    practice_area_id: int,
    designation: str | None = Query(default=None),
    sort: str | None = Query(default=None),
    db: Session = Depends(get_db)
):
    parent = require_practice_area(db, practice_area_id)

    consultants = list(parent.consultants)

    if designation is not None and designation.strip():
        consultants = [
            consultant
            for consultant in consultants
            if consultant.designation == designation
        ]

    if sort is not None:
        if sort not in ("name", "consultation_fee"):
            raise HTTPException(
                status_code=404,
                detail="Invalid sort field"
            )

        consultants.sort(
            key=lambda consultant: getattr(consultant, sort),
            reverse=True
        )

    return {
        "id": parent.id,
        "name": parent.name,
        "floor_number": parent.floor_number,
        "consultants": consultants
    }


# ------------------------------------------------------------
# Endpoint 4: Update a consultant
# ------------------------------------------------------------

@app.put(
    "/practice-areas/{practice_area_id}/consultants/{consultant_id}",
    response_model=ConsultantOut
)
def update_consultant(
    practice_area_id: int,
    consultant_id: int,
    data: ConsultantUpdate,
    db: Session = Depends(get_db)
):
    consultant = require_consultant(
        db,
        practice_area_id,
        consultant_id
    )

    update_data = data.model_dump(exclude_unset=True)

    for field, value in update_data.items():
        if value is None:
            raise HTTPException(
                status_code=422,
                detail=f"{field} cannot be null"
            )

        setattr(consultant, field, value)

    commit_write(db, consultant)

    return consultant


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8080)
