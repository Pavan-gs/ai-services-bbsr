from pydantic import BaseModel, ConfigDict, Field


class PracticeAreaCreate(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")
    name: str = Field(min_length=1)
    floor_number: int = Field(ge=1)


class ConsultantCreate(BaseModel):
    name: str = Field(min_length=1)
    designation: str = Field(min_length=1)
    consultation_fee: int = Field(ge=300)
    experience_years: int = Field(ge=0)

class ConsultantUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1)
    designation: str | None = Field(default=None, min_length=1)
    consultation_fee: int | None = Field(default=None, ge=300)
    experience_years: int | None = Field(default=None, ge=0)    


class ConsultantOut(BaseModel):
    id: int
    name: str
    designation: str
    consultation_fee: int
    experience_years: int

    model_config = ConfigDict(from_attributes=True)


class PracticeAreaOut(BaseModel):
    id: int
    name: str
    floor_number: int

    model_config = ConfigDict(from_attributes=True)


class PracticeAreaWithConsultants(PracticeAreaOut):
    consultants: list[ConsultantOut]
'''

from pydantic import BaseModel, ConfigDict, Field, field_validator

# 1. Shared base for request schemas
class RequestBase(BaseModel):
    model_config = ConfigDict(
        strict=True,
        extra="forbid"
    )

    @field_validator(
        "name",
        "designation",
        check_fields=False
    )
    @classmethod
    def reject_blank_strings(cls, value):
        if isinstance(value, str) and not value.strip():
            raise ValueError("Value must not be blank")
        return value


# 2. Create a practice area
class PracticeAreaCreate(RequestBase):
    name: str
    floor_number: int = Field(ge=1)


# 3. Create a consultant
class ConsultantCreate(RequestBase):
    name: str
    designation: str
    consultation_fee: int = Field(ge=300)
    experience_years: int = Field(ge=0)
# from typing import Annotated
# replacement_cost: Annotated[int, Field(ge=100)]


# 4. Update a consultant
class ConsultantUpdate(RequestBase):
    name: str | None = None
    designation: str | None = None
    consultation_fee: int | None = Field(default=None, ge=300)
    experience_years: int | None = Field(default=None, ge=0)


# 5. Shared base for response schemas
class ORMResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# 6. Consultant response
class ConsultantOut(ORMResponse):
    id: int
    name: str
    designation: str
    consultation_fee: int
    experience_years: int


# 7. Practice area response
class PracticeAreaOut(ORMResponse):
    id: int
    name: str
    floor_number: int


# 8. Practice area with consultants
class PracticeAreaWithConsultants(PracticeAreaOut):
    consultants: list[ConsultantOut]
'''    
